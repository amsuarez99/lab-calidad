#pragma once
#include <math.h>
#include <numeric>
#include <iomanip>
#include <vector>
#include <algorithm>
#include <utility>

class Analizer {
  private:
    int N;
    double xk, r, r2, b0, b1, yk;
    double sumXY, sumX2, sumY2, sumX, sumY;
    double xAvg, yAvg, x2Avg;
    pair<double, vector<pair<double, double> > > data;
    void calcXk(), calcR(), calcR2(), calcB0(), calcB1(), calcYk();
    double sum(vector<double> v);

    void compute();
    void imprimir();


  public:
    Analizer(pair<double, vector<pair<double, double> > > data);
    double* getResults();
    void analize();
};

//.i
Analizer :: Analizer(pair<double, vector<pair<double, double> > > data) {
  this->data = data;
  this->N = data.second.size();
  this->xk = data.first;
}

//.i
double Analizer :: sum(vector<double> v) {
  double sum = accumulate(v.begin(), v.end(), 0.0, [](double x, double y) { return x + y;});
  return sum;
}

//.i
void Analizer :: compute() {
  vector<double> xy;
  xy.resize(data.second.size());
  transform(data.second.begin(), data.second.end(), xy.begin(), [](pair<double, double> p){ return p.first * p.second;} );
  sumXY = sum(xy);

  vector<double> x2;
  x2.resize(data.second.size());
  transform(data.second.begin(), data.second.end(), x2.begin(), [](pair<double, double> p){ return p.first * p.first;} );
  sumX2 = sum(x2);

  vector<double> y2;
  y2.resize(data.second.size());
  transform(data.second.begin(), data.second.end(), y2.begin(),
      [](pair<double, double> p){ return p.second * p.second;} );
  sumY2 = sum(y2);

  vector<double> x;
  x.resize(data.second.size());
  transform(data.second.begin(), data.second.end(), x.begin(), [](pair<double, double> p){ return p.first;});
  sumX = sum(x);

  vector<double> y;
  y.resize(data.second.size());
  transform(data.second.begin(), data.second.end(), y.begin(),
              [](pair<double, double> p){ return p.second; });
  sumY = sum(y);

  xAvg = sumX/N;
  yAvg = sumY/N;
  x2Avg = sumX2/N;
}

//.i
void Analizer :: analize() {
	if(data.second.size() < 2) throw invalid_argument("Error: Para calcular la regresión, se requiren 2 puntos.");
  compute();
  calcB1();
  calcB0();
  calcR();
  calcR2();
  calcYk();


  imprimir();
}

//.i
void Analizer :: calcB1() {
  double numerator = sumXY - (N * xAvg * yAvg);
  double denominator = sumX2 - (N * xAvg * xAvg);
  b1 = numerator/denominator;
}

//.i
void Analizer :: calcB0() {
  b0 = yAvg - b1 * xAvg;
}

//.i
void Analizer :: calcR() {
  double numerator = N *sumXY - (sumX * sumY);
  double denominator = sqrt((N*sumX2 - pow(sumX,2)) * (N * sumY2 - pow(sumY, 2)));
  r = numerator/denominator;
}

//.i
void Analizer :: calcR2() {
  r2 = r*r;
}

//.i
void Analizer :: calcYk() {
  yk = b0 + b1*xk;
}

//.i
void Analizer :: imprimir() {
  cout<< "N  = " << N << endl;
  cout<< "xk = " << xk << endl;
  cout<< fixed << setprecision(5);
  cout<< "r  = " << r << endl;
  cout<< "r2 = " << r2 << endl;
  cout<< "b0 = " << b0 << endl;
  cout<< "b1 = " << b1 << endl;
  cout<< "yk = " << yk << endl;
}
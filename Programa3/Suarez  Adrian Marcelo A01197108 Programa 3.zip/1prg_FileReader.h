//.b=74
#pragma once
#include <algorithm>
#include <fstream>
#include <vector>
#include <string>
#include <utility>
//.d=1

//.i
class FileReader {
  private:
    ifstream inputFile;
    double xk;
    pair<double, vector<pair<double, double>>> data;
    pair<double, double> getXY(string line);
    //.d=3

  public:
    void openFile(string fileName);
    void readFile(); //.m
    void closeFile();
    pair<double, vector<pair<double, double>>> getData();
};

//.d=4
//.i
void FileReader :: openFile(string fileName) {
  //.d=2
  this->inputFile.open(fileName);
  if(!inputFile) throw invalid_argument("Error: El archivo no existe"); //.m
  if(inputFile.peek() == ifstream::traits_type::eof()) throw invalid_argument("Error: El archivo está vacío"); //.m
}

//.i
void FileReader :: closeFile() {
  inputFile.close();
}

//.i
// Funci√≥n: Lee el archivo l√≠nea por l√≠nea y guarda los tipos de l√≠neas en variables
// locales.
// Par√°metros: ninguno
// Valor de retorno: nada
void FileReader :: readFile() {
  string line; //.m
  pair<double, double> xy;
  getline(inputFile, line);
  try {
    xk = stod(line);
    data.first = xk;
  } catch(exception &e) { throw invalid_argument("Error: El valor de xk debe ser un número real mayor o igual a 0"); }

  if(xk < 0) throw invalid_argument("Error: El valor de xk debe ser un número real mayor o igual a 0");
  while (!inputFile.eof()) {
    getline(inputFile, line);
    xy = getXY(line);
    data.second.push_back(xy);
    //.d=2
  }
  //.d=2
}

//.i
pair<double, double> FileReader :: getXY(string line) {
  string sX, sY;
  double dX, dY;

  int commaPos = line.find(',');
	if(commaPos == -1) {
		throw invalid_argument("Error: Una de las líneas de pares no contiene pares.");
	}
  sX = line.substr(0, commaPos);
  sY = line.substr(commaPos+1);

  try {
    dX = stod(sX);
    dY = stod(sY);
  } catch(exception &e) { throw invalid_argument("Error: La lista de pares debe contener valores numéricos."); }

  if(dX < 0 || dY < 0) {
    throw invalid_argument("Error: La lista de pares debe de contener valores mayores o iguales a 0.");
  }

  return make_pair(dX, dY);
}

//.i
pair<double, vector<pair<double, double>>> FileReader :: getData() {
  return data;
}

// Descripción del programa: Predice el valor de una y dado una x, mediante el regresión lineal dado un set de puntos
// 20 de marzo de 2021

//.b=22
#include <iostream>
#include <string>
#include <stdio.h>
#include <vector>
using namespace std;

//.d=1
#include "Analizer.h"
#include "FileReader.h"

//.i
void setup(string &fileName, FileReader &fileReader){
  fileReader.openFile(fileName);
  fileReader.readFile();
  fileReader.closeFile();
}

//.i
int main() {
  try {
    FileReader fileReader;
    string fileName;
    // first is xk, second are the x and y pairs
    pair<double, vector<pair<double, double>>> data;
    cout << "Introduce el nombre del archivo\n> ";
    //.d=1
    getline(cin,fileName);
    //.d=4
    setup(fileName, fileReader);
    data = fileReader.getData();

    Analizer analizer(data);
    analizer.analize();
    //.d=2
  } catch(exception &e) { cerr << e.what() << endl;}
  return 0;
}

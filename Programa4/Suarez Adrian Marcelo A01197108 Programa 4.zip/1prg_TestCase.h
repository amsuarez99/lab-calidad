// Descripción: Encapsula los datos de entrada
// Autor: Adrián Marcelo Suárez Ponce A01197108
// Fecha: 27 de marzo de 2021
#pragma once
class TestCase {
    private: 
    double x, result;
    int dof;

    public: 
    double getX() {return x;};
    void setX(double x) {this->x = x;};
    int getDof() {return dof;};
    void setDof(int dof) {this->dof = dof;};
    double getResult() {return result;};
    void setResult(double result) {this->result = result;};
};
// Descripción: Calcula la integral de una distribución t dada una x y grados de libertad
// Autor: Adrián Marcelo Suárez Ponce A01197108
// Fecha: 27 de marzo de 2021

//.b=24
#include <iostream>
#include <iomanip>
#include <string>
//.d = 4

#include "TestCase.h"
#include "Calculator.h"
#define NUM_SEGMENTS 10
#define ERROR 0.0000001
using namespace std;
//.d = 2

//.i
// Función: Despliega un mensaje de error.
// Parámetros: message: string <- mensaje que se desea desplegar.
// Valor de retorno: void
void displayErrMess(string message) {
  cerr << "Error: " << message << endl;
}

//.i
// Función: Función que maneja los datos de entrada del programa
// Parámetros: nada
// Valor de retorno: TestCase <- datos parseados en una clase
TestCase getInput(){ //.m
  TestCase aux;
  double x;
  int dof;
  string input;
  bool isValidEntry;

  cout << "Este programa calcula el área bajo la curva (p) de una distribución t";
  cout << ", dada un valor (x) y los grados de libertad (dof)." << endl;
  cout << "Por favor, introduce los valores que se te pide." << endl;

  do {
    cout << "x?> ";
    cin >> input;
    isValidEntry = true;

    for(char c: input) {

      if(!isdigit(c) && c != '.') {
        isValidEntry = false;
        displayErrMess("el valor de x debe ser un número real mayor o igual a 0.");
        break;
      }
    }

    if (isValidEntry)
    { 
      x = stod(input);
      if(x < 0) {
        displayErrMess("el valor de x debe ser un número real mayor o igual a 0.");
        isValidEntry = false;
      } 
    }
  } while (!isValidEntry);

  do {
    cout << "dof?> ";
    cin >> input;
    isValidEntry = true;

    for(char c: input) {
      if(!isdigit(c)) {
        isValidEntry = false;
        displayErrMess("el valor de dof debe ser un número entero mayor a 0.");
        break;
      }
    }

    if (isValidEntry)
    { 
      dof = stoi(input);
      if(dof <= 0) {
        displayErrMess("el valor de dof debe ser un número entero mayor a 0.");
        isValidEntry = false;
      } 
    }
  } while (!isValidEntry);

  aux.setX(x);
  aux.setDof(dof);
  return aux;
}

//.i
// Función: Funcion que contiene los pasos de ejecución del programa
// Parámetros: testCase <- datos introducidos, calc <- clase que hace los cálculos
// Valor de retorno: void
void calculate(TestCase &testCase, Calculator calc) {
  double oldRes, newRes;
  calc.setTestCase(testCase);
  
  int multiplier = 1;
  oldRes = calc.integrateSimpson(NUM_SEGMENTS * multiplier);
  multiplier *= 2;
  newRes = calc.integrateSimpson(NUM_SEGMENTS * multiplier);
  while(fabs(newRes - oldRes) > ERROR) {
    multiplier*=2;
    oldRes = newRes;
    newRes = calc.integrateSimpson(NUM_SEGMENTS * multiplier);
  }
  testCase.setResult(newRes);
}

//.i
// Función: Función que imprime los datos en el formato esperado.
// Parámetros: testCase <- datos introducidos
// Valor de retorno: void
void printResult(TestCase &testCase) {
  cout << fixed << setprecision(5);
  cout << "  x = " << testCase.getX() << endl;
  cout << fixed << setprecision(0);
  cout << "dof = " << fixed << setprecision(5) << testCase.getDof() << endl;
  cout << fixed << setprecision(5);
  cout << "  p = " << testCase.getResult() << endl;
}

int main() {
  //.d = 1
  Calculator calculator;
  TestCase testCase;
  testCase = getInput();
  calculate(testCase, calculator);
  printResult(testCase);
  //.d=10
  return 0;
}
